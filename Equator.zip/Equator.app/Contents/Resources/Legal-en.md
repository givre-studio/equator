## Legal notice
Publisher of Equator: Elow Labs. Publication director: Elow Labs.
Contact: frost-browser@proton.me — for any question, request or report (including security issues).
Downloads and updates are hosted by GitHub, Inc., 88 Colin P. Kelly Jr. Street, San Francisco, CA 94107, United States.
The Equator name, logo, the Halo mascot, the interface, code and texts are protected by French intellectual property law. Third-party service names and logos shown in Equator (for example in Equator Cinéma) belong to their owners; there is no partnership with these services.
These texts were last updated on October 29, 2026. The French version prevails.

## Privacy policy
Equator collects no personal data: zero telemetry, zero account, zero advertising, zero resale (GDPR). Elow Labs has no access to any of your data.
- No usage statistics, crash reports or device identifiers are sent.
- History, Logbook, tabs, favorites, bookmarks, Notebook and shield statistics stay in your Mac's Application Support folder.
- Passwords stay in the macOS Keychain, on this Mac.
- Conversations with the Alizés stay on your Mac; the AI model (Apple Intelligence or Ollama) runs locally.
- Connections Equator makes on its own: checking for and downloading updates (GitHub), site icons (without cookies), Alizés web searches if you use them, downloading Ollama if you ask for it. None of these connections carries personal data.
You exercise your GDPR rights (art. 15–21) directly on your device: Settings › Shield › Data erases everything. For any question: frost-browser@proton.me. You can also contact the CNIL (www.cnil.fr).

## Terms of use
Equator is a free browser published by Elow Labs, with no account and no advertising; using it means accepting these terms.
- License: Equator's source code is published under the MIT license. Signed builds should only be downloaded from Elow Labs' official sources.
- Updates: Equator updates itself automatically from Elow Labs' official releases. Security fixes install automatically, for your protection.
- You remain responsible for your browsing and for following the terms of the sites and services you use, including in Equator Cinéma, which uses your own accounts.
- Local server (Ollama / third-party models): running large language models on a Mac puts heavy load on the processor, unified memory and battery. On passively cooled machines (MacBook Air) this can cause overheating, severe slowdowns or forced shutdowns. This option is for advanced users with suitable hardware (MacBook Pro with active cooling, Mac Studio, at least 16 GB of unified memory). Elow Labs accepts no liability for system instability or data loss caused by uncalibrated third-party models. Apple Intelligence remains the recommended engine.
- Alizés answers may be inaccurate: check important information. They only act in your pages when you ask them to, never fill in passwords or payment data, and can ask for your approval before each action (Settings › Alizés).
- Equator is provided as is; nothing limits the rights French law grants consumers.
- French law. In case of disagreement, first write to frost-browser@proton.me to find an amicable solution; failing that, the competent French courts.

## Cookies and trackers
Equator and its download pages set no measurement, advertising or social-network cookies or trackers: no consent banner is needed.
Sites you visit may set their own cookies, stored on your Mac. Equator automatically refuses consent banners, blocks third-party cookies and tracking domains, strips tracking parameters from links, sends the Global Privacy Control signal, and destroys private-browsing cookies when you close it. Settings › Shield lets you manage and erase everything.
